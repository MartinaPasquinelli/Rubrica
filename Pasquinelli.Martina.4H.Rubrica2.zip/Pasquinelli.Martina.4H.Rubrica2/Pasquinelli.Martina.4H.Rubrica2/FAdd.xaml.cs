﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Pasquinelli.Martina._4H.Rubrica2
{
    /// <summary>
    /// Logica di interazione per FAdd.xaml
    /// </summary>
    public partial class FAdd : Window
    {
        public bool exit;

        public FAdd()
        {
            InitializeComponent();
        }

        private void Button_Click_Save(object sender, RoutedEventArgs e)
        {
            exit = true;
            this.Close();
        }

        private void Button_Click_Exit(object sender, RoutedEventArgs e)
        {
            exit = false;
            this.Close();
        }
    }
}
