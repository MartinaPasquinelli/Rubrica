﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Pasquinelli.Martina._4H.Rubrica2
{
    /// <summary>
    /// Logica di interazione per MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Persona> persone = new List<Persona>();
        public MainWindow()
        {
            InitializeComponent();
            lettura();
            dgDati.ItemsSource = persone;
        }

        void scrittura()
        {

            StreamWriter fOut = new StreamWriter("Dati.txt");
            for (int i = 0; i < persone.Count; i++)
            {
                fOut.WriteLine(persone[i].ToString());
            }
            fOut.Close();

        }

        void lettura()
        {
            
            StreamReader fIn = new StreamReader("Dati.txt");
            int counter = 0;
            while (!fIn.EndOfStream)
            {
                fIn.ReadLine();
                counter++;
            }
            fIn.Close();
            StreamReader sr = new StreamReader("Dati.txt");
            for (int i = 0; i < counter; i++)
            {
                string riga = sr.ReadLine();

                    persone.Add(new Persona(riga));

            }
            sr.Close();
        }

        private void Btn_Click_add(object sender, RoutedEventArgs e)
        {

            FAdd finestra = new FAdd();
            finestra.ShowDialog();
            Persona nuovo = new Persona();
            if (finestra.exit)
            {
                persone.Add(new Persona($"{finestra.newnome.Text};{finestra.newcognome.Text};{finestra.newcitta.Text};{finestra.newcap.Text};{finestra.newntelefono.Text};{finestra.newdatanascita.Text}"));
                scrittura();

            }
            
            dgDati.Items.Refresh();
        }

        private void Btn_Click_modi(object sender, RoutedEventArgs e)
        {
            int index = dgDati.SelectedIndex;
            FAdd finestra = new FAdd();
            try
            {
                persone[index].FinestraModi(finestra);
                finestra.ShowDialog();
                persone[index] = new Persona($"{finestra.newnome.Text};{finestra.newcognome.Text};{finestra.newcitta.Text};{finestra.newcap.Text};{finestra.newntelefono.Text};{finestra.newdatanascita.Text}");
                scrittura();
            }
            catch
            {
                MessageBox.Show("Selezzionare una casella da modificare");
            }
            dgDati.Items.Refresh();
        }

        private void Btn_Click_delete(object sender, RoutedEventArgs e)
        {
            int index = dgDati.SelectedIndex;
            try
            {
                //persone[index] = new Persona();
                persone.Remove(persone[index]);
                dgDati.Items.Refresh();
                scrittura();
            }
            catch
            {
                MessageBox.Show("Selezzionare una casella da modificare");
            }
        }

        private void Btn_Click_cerca(object sender, RoutedEventArgs e)
        {
            bool aiuto = true;
            List<Persona> item = new List<Persona>();

            for( int i=0;i < persone.Count;i++)
            {
                if (cercaNome.Text == persone[i].Nome)
                {
                    item.Add(persone[i]);
                    aiuto = false;
                }
            }

            if (aiuto == false)
            {
                dgDati.ItemsSource = item;
                dgDati.Items.Refresh();
                cercaNome.Text = "";
            }
            else
            {
                MessageBox.Show("Contatto non presente");
                cercaNome.Text = "";
            }
        }
  
        private void Btn_Click_indietro(object sender, RoutedEventArgs e)
        {
            dgDati.ItemsSource = persone;
        }
    }
}
